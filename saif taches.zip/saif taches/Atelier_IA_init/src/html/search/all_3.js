var searchData=
[
  ['hero',['hero',['../structhero.html',1,'']]]
];
