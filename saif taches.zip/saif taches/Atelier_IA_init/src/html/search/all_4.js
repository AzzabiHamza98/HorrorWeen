var searchData=
[
  ['text',['text',['../structtext.html',1,'']]]
];
