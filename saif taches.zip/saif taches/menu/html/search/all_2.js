var searchData=
[
  ['exit',['exit',['../structbuttons.html#a14ceea4860f4a66e5f6818c0d3a3b748',1,'buttons::exit()'],['../structquitter.html#aaf531694ebe320b9465acf10fc41a973',1,'quitter::exit()']]]
];
