var searchData=
[
  ['backbutton',['backbutton',['../structcommands.html#a633aa5466bc2872056143f54aa9ced8d',1,'commands::backbutton()'],['../structopt.html#a1dbaf62317f3d1d0adc2f89b76358369',1,'opt::backbutton()']]]
];
