var searchData=
[
  ['setting',['setting',['../structbuttons.html#a708d3ac884e55d452246a1fb04472214',1,'buttons']]]
];
