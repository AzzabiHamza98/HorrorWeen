var indexSectionsWithContent =
{
  0: "bceimopqs",
  1: "bcoq",
  2: "imoq",
  3: "cimo",
  4: "beiops"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables"
};

