var searchData=
[
  ['quitter',['quitter',['../structquitter.html',1,'']]]
];
