var searchData=
[
  ['quit_2ec',['quit.c',['../quit_8c.html',1,'']]],
  ['quitter',['quitter',['../structquitter.html',1,'']]]
];
