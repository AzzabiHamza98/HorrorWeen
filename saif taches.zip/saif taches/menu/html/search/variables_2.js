var searchData=
[
  ['instruction',['instruction',['../structcommands.html#a08d402b38eb57a741fda69003ecd2ba9',1,'commands']]],
  ['instructions',['instructions',['../structbuttons.html#a19215992b4dd4409b0dfb46a5638cc9f',1,'buttons']]]
];
