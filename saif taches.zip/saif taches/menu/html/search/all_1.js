var searchData=
[
  ['cleanmenu',['cleanmenu',['../main_8c.html#a5c92bd45d4d47506f430d4c77d1dd23b',1,'main.c']]],
  ['commands',['commands',['../structcommands.html',1,'']]]
];
