var searchData=
[
  ['instruction',['instruction',['../structcommands.html#a08d402b38eb57a741fda69003ecd2ba9',1,'commands']]],
  ['instruction_2ec',['instruction.c',['../instruction_8c.html',1,'']]],
  ['instructions',['instructions',['../structbuttons.html#a19215992b4dd4409b0dfb46a5638cc9f',1,'buttons::instructions()'],['../instruction_8c.html#aebb895af4d3073f20c03b60805e45803',1,'instructions():&#160;instruction.c']]]
];
