var searchData=
[
  ['quit_2ec',['quit.c',['../quit_8c.html',1,'']]]
];
